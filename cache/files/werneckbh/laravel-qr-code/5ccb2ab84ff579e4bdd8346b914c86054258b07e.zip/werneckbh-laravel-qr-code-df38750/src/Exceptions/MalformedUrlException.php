<?php

namespace LaravelQRCode\Exceptions;

class MalformedUrlException extends \Exception
{

}