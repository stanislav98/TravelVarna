<?php

namespace LaravelQRCode\Exceptions;

class EmptyTextException extends \Exception
{

}