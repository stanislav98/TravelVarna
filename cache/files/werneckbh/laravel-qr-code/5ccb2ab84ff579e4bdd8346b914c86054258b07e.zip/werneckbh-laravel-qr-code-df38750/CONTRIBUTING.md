 To contribute to this project, please do the following:
 
  - Fork it
  - Create a new branch for your contribution
  - Test it! Make sure it works and it won't break the master code
  - Send pull request
  
  Contributors will be added to package descriptor
  
  Make sure you abide to the [Contributor Covenant Code of Conduct](CODE_OF_CONDUCT.md)