<?php

namespace Laravel\Socialite\One;

use InvalidArgumentException;

class MissingTemporaryCredentialsException extends InvalidArgumentException
{
    //
}
