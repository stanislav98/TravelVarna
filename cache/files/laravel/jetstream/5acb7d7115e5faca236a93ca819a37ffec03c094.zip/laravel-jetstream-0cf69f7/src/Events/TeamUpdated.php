<?php

namespace Laravel\Jetstream\Events;

class TeamUpdated extends TeamEvent
{
    //
}
